package domI9SUP5;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import org.xml.sax.SAXException;

public class DOMQueryI9SUP5 {

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

        File xmlFile = new File("I9SUP5_XML.xml");

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();

        System.out.println("== DOM LEKÉRDEZÉSEK ==\n");

        // 1. lekérdezés: Összes vendég neve
        System.out.println("1. Összes vendég neve:");
        NodeList vendegList = doc.getElementsByTagName("vendeg");
        for (int i = 0; i < vendegList.getLength(); i++) {
            Element vendeg = (Element) vendegList.item(i);
            String nev = vendeg.getElementsByTagName("nev").item(0).getTextContent();
            System.out.println("- " + nev);
        }

        // 2. lekérdezés: Rendelések, ahol az összeg > 5000
        System.out.println("\n2. Rendelések, ahol az összeg > 5000:");
        NodeList rendelesList = doc.getElementsByTagName("rendeles");
        for (int i = 0; i < rendelesList.getLength(); i++) {
            Element rend = (Element) rendelesList.item(i);
            int osszeg = Integer.parseInt(rend.getElementsByTagName("osszeg").item(0).getTextContent());
            if (osszeg > 5000) {
                System.out.println("- Étel: " + rend.getElementsByTagName("etel").item(0).getTextContent()
                        + ", Összeg: " + osszeg + " Ft");
            }
        }

        // 3. lekérdezés: Gyakornokok műszakjai
        System.out.println("\n3. Gyakornokok és műszakjaik:");
        NodeList gyakornokList = doc.getElementsByTagName("gyakornok");
        for (int i = 0; i < gyakornokList.getLength(); i++) {
            Element gyak = (Element) gyakornokList.item(i);
            String nev = gyak.getElementsByTagName("nev").item(0).getTextContent();
            System.out.print("- " + nev + ": ");
            NodeList muszakList = gyak.getElementsByTagName("muszak");
            for (int j = 0; j < muszakList.getLength(); j++) {
