package domI9SUP5;

import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

public class DOMModifyI9SUP5 {

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

        File xmlFile = new File("I9SUP5_XML.xml");

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();

        NodeList vendegList = doc.getElementsByTagName("vendeg");

        for (int i = 0; i < vendegList.getLength(); i++) {
            Element vendeg = (Element) vendegList.item(i);

            if (vendeg.getAttribute("vkod").equals("v1")) {
                Node nevNode = vendeg.getElementsByTagName("nev").item(0);
                System.out.println("Eredeti név: " + nevNode.getTextContent());

                // Módosítás:
                nevNode.setTextContent("Kiss Péter");

                System.out.println("Módosított név: " + nevNode.getTextContent());
            }
        }
    }
}
