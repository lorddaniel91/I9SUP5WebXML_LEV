package domI9SUP5;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

public class DOMReadI9SUP5 {

    public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {

        File xmlFile = new File("I9SUP5_XML.xml");

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = factory.newDocumentBuilder();

        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();

        System.out.println("Gyökér elem: " + doc.getDocumentElement().getNodeName());

        // === Éttermek ===
        NodeList nList = doc.getElementsByTagName("etterem");
        for (int i = 0; i < nList.getLength(); i++) {
            Element elem = (Element) nList.item(i);
            System.out.println("\n== Étterem ==");
            System.out.println("ID: " + elem.getAttribute("ekod"));
            System.out.println("Név: " + elem.getElementsByTagName("nev").item(0).getTextContent());

            Element cim = (Element) elem.getElementsByTagName("cím").item(0);
            System.out.println("Cím: " +
                    cim.getElementsByTagName("varos").item(0).getTextContent() + ", " +
                    cim.getElementsByTagName("utca").item(0).getTextContent() + " utca " +
                    cim.getElementsByTagName("hazszam").item(0).getTextContent());

            System.out.println("Csillag: " + elem.getElementsByTagName("csillag").item(0).getTextContent());
        }

        // === Főszakácsok ===
        nList = doc.getElementsByTagName("foszakacs");
        for (int i = 0; i < nList.getLength(); i++) {
            Element elem = (Element) nList.item(i);
            System.out.println("\n== Főszakács ==");
            System.out.println("ID: " + elem.getAttribute("fkod"));
            System.out.println("Étterem ID: " + (elem.hasAttribute("e_f") ? elem.getAttribute("e_f") : elem.getAttribute("e_sz")));
            System.out.println("Név: " + elem.getElementsByTagName("nev").item(0).getTextContent());
            System.out.println("Életkor: " + elem.getElementsByTagName("eletkor").item(0).getTextContent());

            NodeList vegz = elem.getElementsByTagName("vegzettseg");
            for (int j = 0; j < vegz.getLength(); j++) {
                System.out.println("Végzettség: " + vegz.item(j).getTextContent());
            }
        }

        // === Szakácsok ===
        nList = doc.getElementsByTagName("szakacs");
        for (int i = 0; i < nList.getLength(); i++) {
            Element elem = (Element) nList.item(i);
            System.out.println("\n== Szakács ==");
            System.out.println("ID: " + elem.getAttribute("szkod"));
            System.out.println("Étterem ID: " + elem.getAttribute("e_sz"));
            System.out.println("Név: " + elem.getElementsByTagName("nev").item(0).getTextContent());
            System.out.println("Részleg: " + elem.getElementsByTagName("reszleg").item(0).getTextContent());

            NodeList vegz = elem.getElementsByTagName("vegzettseg");
            for (int j = 0; j < vegz.getLength(); j++) {
                System.out.println("Végzettség: " + vegz.item(j).getTextContent());
            }
        }

        // === Gyakornokok ===
        nList = doc.getElementsByTagName("gyakornok");
        for (int i = 0; i < nList.getLength(); i++) {
            Element elem = (Element) nList.item(i);
            System.out.println("\n== Gyakornok ==");
            System.out.println("ID: " + elem.getAttribute("gykod"));
            System.out.println("Étterem ID: " + elem.getAttribute("e_gy"));
            System.out.println("Név: " + elem.getElementsByTagName("nev").item(0).getTextContent());

            Element gyakorlat = (Element) elem.getElementsByTagName("gyakorlat").item(0);
            System.out.println("Gyakorlat kezdete: " + gyakorlat.getElementsByTagName("kezdete").item(0).getTextContent());
            System.out.println("Időtartam: " + gyakorlat.getElementsByTagName("idotartama").item(0).getTextContent());

            NodeList muszakok = elem.getElementsByTagName("muszak");
            for (int j = 0; j < muszakok.getLength(); j++) {
                System.out.println("Műszak: " + muszakok.item(j).getTextContent());
            }
        }

        // === Vendégek ===
        nList = doc.getElementsByTagName("vendeg");
        for (int i = 0; i < nList.getLength(); i++) {
            Element elem = (Element) nList.item(i);
            System.out.println("\n== Vendég ==");
            System.out.println("ID: " + elem.getAttribute("vkod"));
            System.out.println("Név: " + elem.getElementsByTagName("nev").item(0).getTextContent());
            System.out.println("Életkor: " + elem.getElementsByTagName("eletkor").item(0).getTextContent());

            Element cim = (Element) elem.getElementsByTagName("cim").item(0);
            System.out.println("Cím: " +
                    cim.getElementsByTagName("varos").item(0).getTextContent() + ", " +
                    cim.getElementsByTagName("utca").item(0).getTextContent() + " utca " +
                    cim.getElementsByTagName("hazszam").item(0).getTextContent());
        }

        // === Rendelések ===
        nList = doc.getElementsByTagName("rendeles");
        for (int i = 0; i < nList.getLength(); i++) {
            Element elem = (Element) nList.item(i);
            System.out.println("\n== Rendelés ==");
            System.out.println("Étterem ID: " + elem.getAttribute("e_v_e"));
            System.out.println("Vendég ID: " + elem.getAttribute("e_v_v"));
            System.out.println("Összeg: " + elem.getElementsByTagName("osszeg").item(0).getTextContent());
            System.out.println("Étel: " + elem.getElementsByTagName("etel").item(0).getTextContent());
        }
    }
}
